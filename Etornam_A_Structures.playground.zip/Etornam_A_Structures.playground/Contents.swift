import UIKit
// variables
struct engine {
    var engineOne = ""
    var engineTwo = ""
    var engineThree = ""
    
    func allengine() -> String {
        return "My car has three awesome engines:" + "\n" + engineOne + "" + engineTwo + "" + engineThree
    }
}

// opperation
var vroomVroom = engine (engineOne: "V4", engineTwo: "V6", engineThree: "V8")

vroomVroom.allengine()

print (vroomVroom.allengine())
